/*
 * Entry point for the companion app
 */
import document from "document";
console.log("Companion code started");

/*

let dots = document.getElementById("pagination-dots");

var i;
for (i = 0; i < 5; i++) {
  var dotEl = document.createElement("use")
  dotEl.setAttribute("href", "#pagination-dot")
  //dotEl.setAttribute("fill", "red")
  dots.appendChild(dotEl)
  console.log("added a dot...")
} 
*/