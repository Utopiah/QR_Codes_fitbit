/*
 * Entry point for the watch app
 */
console.log('hi from watch')

/*
container

    <use id="item1" href="#panoramaview-item">
      <image x="16" y="10" width="32" height="32" href="icons/linked.png" />
        <g transform="rotate(90)">
          <text x="40%" y="-10"
              font-family="System-Regular" fill="black"
              font-size="30" font-weight="bold"
              text-anchor="middle">LinkedIn</text>
        </g>
       <image x="20%" width="75%" height="100%" href="qrcodes/linked.png" />
    </use>
*/

import document from "document";

/*
let img = document.getElementById("testing-query");
img.fill = "green";
*/